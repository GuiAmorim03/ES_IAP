package ua.pt.es.to_do_list.models;

public enum Status {
    PENDING,
    IN_PROGRESS,
    DONE
}
