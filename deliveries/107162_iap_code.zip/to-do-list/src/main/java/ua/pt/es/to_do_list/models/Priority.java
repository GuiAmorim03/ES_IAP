package ua.pt.es.to_do_list.models;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH    
}
